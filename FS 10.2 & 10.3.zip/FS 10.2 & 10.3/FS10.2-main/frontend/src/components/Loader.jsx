export default function Loader() {
  return (
    <div style={{
      textAlign: "center", marginTop: "40px", fontSize: "1.5rem", color: "#555"
    }}>
      ⏳ Loading...
    </div>
  );
}
